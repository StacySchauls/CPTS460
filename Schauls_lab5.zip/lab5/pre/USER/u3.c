#include "ucode.c"

main()
{
  ubody("three");
}
