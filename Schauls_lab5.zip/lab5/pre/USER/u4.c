#include "ucode.c"

main()
{
  ubody("four");
}
